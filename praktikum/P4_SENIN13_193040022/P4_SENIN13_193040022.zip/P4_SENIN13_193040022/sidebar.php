<!DOCTYPE html>
<html>
<head>
	<title>Sidebar</title>
	<style type="text/css">
		body {
			font-family: Adobe Fangsong Std R;
			font-size: 15px;
			color: white;
		}

		a:link {
			color: white;
			text-decoration: none;
		}

		a:visited {
			color: white;
			text-decoration: none;
		}

		a:hover {
			color: white;
			text-decoration: underline;
		}

		a:active {
			color: white;
			text-decoration: none;
		}
	</style>
</head>
<body bgcolor="#800000">
	<center>
		<h1>Yanida Nur Nabila Widya Sastra</h1>
	</center>
		<br>
		<br>
	<ul type="1">
		<a href="Latihan4a.php" target="sites">Latihan 4a</a>
		<br>
		<a href="Latihan4b.php" target="sites">Latihan 4b</a>
		<br>
		<a href="Latihan4c.php" target="sites">Latihan 4c</a>
		<br>
		<a href="Latihan4d.php" target="sites">Latihan 4d</a>
        <br>
        <a href="Tugas2.php" target="sites">Tugas 2</a>
		<br>
		<br>
		<br>
		<br>
		<br>
		<p><h2>193040022</h2></p>
	</ul>
</body>
</html>