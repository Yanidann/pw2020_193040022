<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>
	<frameset cols="20%,*" border="0">
		<frame name="sidebar" src="sidebar.php"></frame>
		<frame name="sites" src=""></frame>
	</frameset>
<body>
<?php 
   include 'index.php';
   ?>
</body>
</html>