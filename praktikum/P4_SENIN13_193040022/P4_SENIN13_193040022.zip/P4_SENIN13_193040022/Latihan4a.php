<?php
    $value = ["ada", "abel", "men", "pung", "nilai"];
    echo "Array $value[0]lah suatu vari$value[1] yang dapat $value[2]am$value[3] banyak $value[4]";
?>