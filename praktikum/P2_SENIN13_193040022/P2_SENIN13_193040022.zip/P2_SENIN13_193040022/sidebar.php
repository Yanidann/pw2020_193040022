<!DOCTYPE html>
<html>
<head>
	<title>Sidebar</title>
	<style type="text/css">
		body {
			font-family: Adobe Fangsong Std R;
			font-size: 15px;
			color: white;
		}

		a:link {
			color: white;
			text-decoration: none;
		}

		a:visited {
			color: white;
			text-decoration: none;
		}

		a:hover {
			color: white;
			text-decoration: underline;
		}

		a:active {
			color: white;
			text-decoration: none;
		}
	</style>
</head>
<body bgcolor="#800000">
	<center>
		<h1>Yanida Nur Nabila Widya Sastra</h1>
	</center>
		<br>
		<br>
	<ul type="1">
		<a href="Latihan2a.php" target="sites">Latihan 2a</a>
		<br>
		<a href="Latihan2b.php" target="sites">Latihan 2b</a>
		<br>
		<a href="Latihan2c.php" target="sites">Latihan 2c</a>
		<br>
		<a href="Tugas1.php" target="sites">Tugas 1</a>
		<br>
		<br>
		<br>
		<br>
		<br>
		<p><h2>193040022</h2></p>
	</ul>
</body>
</html>